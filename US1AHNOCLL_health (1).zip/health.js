const input = document.querySelector('input');
const button = document.querySelector('button');
const output = document.querySelector('.output');

button.addEventListener('click', function() {
    const command = input.value.toLowerCase();

    if (command === 'hello') {
        output.innerHTML += '<p>Virtual Assistant: Hi there!</p>';
    } else if (command === 'play music') {
        output.innerHTML += '<p>Virtual Assistant: Playing some music for you.</p>';
    } else if (command === 'set alarm') {
        output.innerHTML += '<p>Virtual Assistant: Alarm is set for 8am.</p>';
    } else if (command === 'schedule appointment') {
        output.innerHTML += '<p>Virtual Assistant: Your appointment is scheduled for next Wednesday at 2pm.</p>';
    } else if (command === 'take medication') {
        output.innerHTML += '<p>Virtual Assistant: It is time for you to take your medication.</p>';
    } else if (command === 'thank you') {
        output.innerHTML += '<p>Virtual Assistant: You are welcome!</p>';
    } else {
        output.innerHTML += '<p>Virtual Assistant: I did not understand your command.</p>';
    }

    input.value = '';
});